"""AstrBot 记忆归档插件。

解决的问题：长对话每次请求都把全部历史塞给模型，token 爆炸。
做法：在重置对话前把历史「存档」成按日期命名的 Markdown，之后再按日期/关键词回忆。

对外提供：
  指令   /存档 [下次提示]     把当前对话存进今天的文档
  指令   /回忆 <日期或关键词>  翻档案，结果注入下一轮上下文
  指令   /查档 [关键词]        列出所有档案（带摘要和 token 量）
  指令   /档案状态            看当前对话有多重

  LLM 工具 recall_archive(date, keyword)  让模型自己按需翻档案

自动行为：
  - 重置/换会话前如果没存档，自动兜底存一次
  - 每轮对话在 system prompt 里注入「档案目录」，模型知道哪天聊过什么
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from astrbot.api import AstrBotConfig, llm_tool, logger, star
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.core.star.filter.command import GreedyStr

from .archiver import (
    ArchiveStore,
    estimate_tokens,
    normalize_date,
    content_to_text,
    history_to_turns,
    render_turns_compact,
)

PLUGIN_NAME = "astrbot_plugin_memory_archive"


class MemoryArchivePlugin(star.Star):
    def __init__(self, context: star.Context, config: AstrBotConfig) -> None:
        super().__init__(context)
        self.config = config
        self._store: ArchiveStore | None = None
        # 已经提醒过「今天还没存档」的会话，避免每次都念一遍
        self._nudged: set[str] = set()
        # v0.2：每个会话累计了多少轮、是否已经做过「重置后续接」
        self._turn_counts: dict[str, int] = {}
        self._resumed: set[str] = set()

    # ------------------------------------------------------------ 配置读取

    def _cfg(self, key: str, default):
        try:
            return self.config.get(key, default)
        except Exception:
            return default

    def _bot_name(self) -> str:
        return str(self._cfg("bot_name", "小肥鲸鱼") or "小肥鲸鱼")

    def store(self) -> ArchiveStore:
        if self._store is None:
            docs_dir = str(self._cfg("docs_dir", "") or "").strip()
            if not docs_dir:
                # 默认放在插件自己的 data 目录下
                base = Path(__file__).resolve().parent
                docs_dir = str(base / "docs")
            self._store = ArchiveStore(docs_dir, bot_name=self._bot_name())
            logger.info(f"[记忆归档] 档案目录: {self._store.docs_dir}")
        return self._store

    def _admin_only(self) -> bool:
        return bool(self._cfg("admin_only", False))

    def _allowed(self, event: AstrMessageEvent) -> bool:
        if not self._admin_only():
            return True
        try:
            return bool(event.is_admin())
        except Exception:
            return False

    def _session_key(self, event: AstrMessageEvent) -> str:
        try:
            return event.unified_msg_origin
        except Exception:
            try:
                return event.get_session_id()
            except Exception:
                return "default"

    # ------------------------------------------------------------ 取历史

    async def _current_history(self, event: AstrMessageEvent) -> list[dict]:
        """读出当前会话的完整 history（不只是发给模型的那部分）。"""
        umo = self._session_key(event)
        cm = self.context.conversation_manager
        cid = await cm.get_curr_conversation_id(umo)
        if not cid:
            return []
        conv = await cm.get_conversation(umo, cid)
        if not conv:
            return []

        try:
            history = json.loads(conv.history) if isinstance(conv.history, str) else conv.history
        except Exception:
            return []
        return history if isinstance(history, list) else []

    # ------------------------------------------------------------ 存档

    async def _do_archive(
        self,
        event: AstrMessageEvent,
        *,
        next_prompt: str = "",
        date: str | None = None,
    ):
        history = await self._current_history(event)
        if not history:
            return None, "当前对话是空的，没什么可存的。"

        turns = history_to_turns(history, with_tools=bool(self._cfg("keep_tool_notes", True)))
        if not turns:
            return None, "没解析出有效对话内容。"

        date = date or datetime.now().strftime("%Y-%m-%d")
        result = self.store().append_turns(
            date,
            turns,
            summary="",
            next_prompt=next_prompt,
            overlap=int(self._cfg("history_overlap_guess", 0) or 0),
        )
        logger.info(
            f"[记忆归档] {date} 存入 {result.turns_added} 轮（累计 {result.turns_total} 轮，约 {result.tokens} tokens）"
        )
        return result, None

    @filter.command("存档")
    async def cmd_archive(self, event: AstrMessageEvent, hint: GreedyStr = ""):
        """把当前对话存档到按日期命名的文档。"""
        if not self._allowed(event):
            yield event.plain_result("这个指令仅限管理员使用。")
            return

        hint = str(hint or "").strip()
        result, err = await self._do_archive(event, next_prompt=hint)
        if err:
            yield event.plain_result(f"存档失败：{err}")
            return

        lines = [
            f"已存档到 {result.date}",
            f"本轮新增 {result.turns_added} 轮，档案累计 {result.turns_total} 轮（约 {result.tokens} tokens）",
            f"文件：{result.path.name}",
        ]
        if hint:
            lines.append(f"下次提示已记录：{hint}")
        lines.append("")
        lines.append("现在可以放心 /reset 了，下次用 /回忆 找回。")
        yield event.plain_result("\n".join(lines))

    async def try_auto_archive(self, event: AstrMessageEvent) -> str | None:
        """重置前兜底存档，返回提示文本或 None。"""
        if not bool(self._cfg("auto_archive_before_reset", True)):
            return None
        try:
            result, err = await self._do_archive(event)
            if result:
                return f"（重置前已自动存档到 {result.date}.md，{result.turns_total} 轮）"
        except Exception as e:
            logger.warning(f"[记忆归档] 自动存档失败: {e}")
        return None

    # reset 前自动存档。
    #
    # 为什么不直接 @filter.command("reset")：那会和内置 /reset 撞名，
    # 管理面板里会挂一条刺眼的"有冲突"。这里改用监听器，既能抢在内置
    # reset 之前执行（priority 999），又不占用命令名。
    @filter.event_message_type(
        filter.EventMessageType.ALL, priority=999
    )
    async def auto_archive_on_reset(self, event: AstrMessageEvent):
        # 只关心"重置类指令"，别的消息直接放行
        if not self._is_reset_command(event):
            return
        note = await self.try_auto_archive(event)
        if note:
            try:
                await event.send(event.plain_result(note))
            except Exception as e:
                logger.warning(f"[记忆归档] 发送存档提示失败: {e}")

    @filter.on_llm_response()
    async def auto_archive_every_n_turns(self, event: AstrMessageEvent, resp) -> None:
        """每聊满 N 轮就自动落一份盘（v0.2）。

        为什么需要它：原来只有手动 /存档 和 reset 前兜底两种时机。
        一旦进程被杀、或者哪次上下文被清短，没存档的那段就彻底没了
        （2026-11-01 15:01 那次就是这么丢的 70 条）。定时落盘把损失上限压到 N 轮。

        只对私聊生效：群里量太大，而且真丢了也没人在意。
        """
        every = int(self._cfg("auto_archive_every_turns", 8) or 0)
        if every <= 0:
            return
        try:
            if not event.is_private_chat():
                return
        except Exception:
            return
        try:
            umo = self._session_key(event)
            n = self._turn_counts.get(umo, 0) + 1
            self._turn_counts[umo] = n
            if n % every:
                return
            result, err = await self._do_archive(event)
            if result:
                logger.info(
                    f"[记忆归档] 自动存档（第 {n} 轮）：{result.date} "
                    f"累计 {result.turns_total} 轮，约 {result.tokens} tokens"
                )
            elif err:
                logger.debug(f"[记忆归档] 自动存档跳过: {err}")
        except Exception as e:
            logger.warning(f"[记忆归档] 自动存档失败: {e}")

    def _is_reset_command(self, event: AstrMessageEvent) -> bool:
        """判断这条消息是不是内置的 /reset 或 /new。

        兼容 wake 前缀、全角斜杠和各种空白写法。
        """
        try:
            text = event.get_message_str() or ""
        except Exception:
            return False
        text = text.strip().lstrip("!！/／")
        if not text:
            return False
        head = text.split()[0].lower() if text.split() else ""
        targets = {"reset", "new"}
        # 面板里可以改 command 名，所以用配置兜底
        extra = str(self._cfg("reset_aliases", "") or "").strip()
        if extra:
            targets |= {x.strip().lower() for x in extra.split(",") if x.strip()}
        return head in targets

    # ------------------------------------------------------------ 回忆

    def _format_recall(self, date: str, *, max_chars: int) -> str:
        store = self.store()
        body = store.read_body(date)
        if not body:
            dates = store.list_dates()
            if not dates:
                return f"没有找到 {date} 的档案。目前一份档案都还没有。"
            recent = "、".join(dates[-7:])
            return f"没有找到 {date} 的档案。已有档案日期：{recent}"

        summary = store.summary_of(date)
        text = body.strip()
        if len(text) > max_chars:
            text = text[:max_chars].rstrip() + "\n\n……（档案太长，后面省略）"

        head = f"【{date} 的对话档案】"
        if summary:
            head += f"\n那天聊了：{summary}"
        return head + "\n\n" + text

    @filter.command("回忆")
    async def cmd_recall(self, event: AstrMessageEvent, query: GreedyStr = ""):
        """按日期或关键词回忆档案。"""
        if not self._allowed(event):
            yield event.plain_result("这个指令仅限管理员使用。")
            return

        query = str(query or "").strip()
        if not query:
            yield event.plain_result("用法：/回忆 2026-10-28   或   /回忆 昨天   或   /回忆 显卡")
            return

        max_chars = int(self._cfg("recall_max_chars", 6000) or 6000)
        store = self.store()

        date = normalize_date(query)
        if date:
            text = self._format_recall(date, max_chars=max_chars)
            yield event.plain_result(text)
            return

        # 不是日期，当关键词搜
        hits = store.search(query, limit=int(self._cfg("search_limit", 3) or 3))
        if not hits:
            dates = store.list_dates()
            tail = f"已有档案：{'、'.join(dates[-7:])}" if dates else "目前还没有任何档案。"
            yield event.plain_result(f"没搜到「{query}」。{tail}")
            return

        parts = [f"在 {len(hits)} 天里找到了「{query}」："]
        for h in hits:
            parts.append(f"\n=== {h['date']} ===")
            if h["summary"]:
                parts.append(f"（那天：{h['summary']}）")
            for snip in h["snippets"]:
                parts.append(snip)
        text = "\n".join(parts)
        if len(text) > max_chars:
            text = text[:max_chars].rstrip() + "\n\n……（结果太长，后面省略）"
        yield event.plain_result(text)

    @filter.command("查档")
    async def cmd_list(self, event: AstrMessageEvent, keyword: GreedyStr = ""):
        """列出所有档案。"""
        if not self._allowed(event):
            yield event.plain_result("这个指令仅限管理员使用。")
            return

        keyword = str(keyword or "").strip()
        store = self.store()
        dates = store.list_dates()

        if keyword:
            hits = store.search(keyword, limit=int(self._cfg("search_limit", 5) or 5))
            if not hits:
                yield event.plain_result(f"没有档案提到「{keyword}」。")
                return
            lines = [f"提到「{keyword}」的档案："]
            for h in hits:
                lines.append(f"· {h['date']}  {h['summary'] or '（无摘要）'}")
            yield event.plain_result("\n".join(lines))
            return

        if not dates:
            yield event.plain_result("目前还没有任何档案。用 /存档 存一份试试。")
            return

        lines = [f"共 {len(dates)} 天档案（最近 20 天）："]
        for d in dates[-20:]:
            toks = store.tokens_of(d)
            summ = store.summary_of(d)
            line = f"· {d}  约 {toks} tokens"
            if summ:
                line += f"  {summ}"
            lines.append(line)
        yield event.plain_result("\n".join(lines))

    @filter.command("档案状态")
    async def cmd_status(self, event: AstrMessageEvent):
        """看当前对话有多重。"""
        if not self._allowed(event):
            yield event.plain_result("这个指令仅限管理员使用。")
            return

        history = await self._current_history(event)
        if not history:
            yield event.plain_result("当前对话是空的。")
            return

        chars = 0
        msgs = 0
        texts: list[str] = []
        for m in history:
            if isinstance(m, dict):
                t = content_to_text(m.get("content"))
                chars += len(t)
                texts.append(t)
                msgs += 1
        toks = estimate_tokens("\n".join(texts))

        store = self.store()
        today = datetime.now().strftime("%Y-%m-%d")
        archived = store.path_for(today).is_file()

        lines = [
            f"当前对话：{msgs} 条消息，约 {chars} 字符，估计 {toks} tokens",
            f"今天({today})的档案：{'已存在' if archived else '还没有'}",
            f"档案目录共 {len(store.list_dates())} 天",
        ]
        if toks > int(self._cfg("warn_tokens", 8000) or 8000):
            lines.append("")
            lines.append("已经挺重了，建议 /存档 后 /reset。")
        yield event.plain_result("\n".join(lines))

    # ------------------------------------------------------------ LLM 工具

    @llm_tool("recall_archive")
    async def tool_recall(self, event: AstrMessageEvent, date: str = "", keyword: str = ""):
        """翻看过去某天或某个关键词的对话档案。当用户提到"之前""上次""那天"或某个过去的话题时使用。

        Args:
            date(string): 日期，格式 YYYY-MM-DD。也可以传"昨天""前天"。留空则按关键词搜索。
            keyword(string): 要在档案里搜索的关键词。date 为空时必填。
        """
        store = self.store()
        max_chars = int(self._cfg("tool_max_chars", 4000) or 4000)

        if date:
            d = normalize_date(date)
            if not d:
                return f"没能理解日期「{date}」，请用 YYYY-MM-DD 格式。"
            return self._format_recall(d, max_chars=max_chars)

        if keyword:
            hits = store.search(keyword, limit=2)
            if not hits:
                return f"档案里没有关于「{keyword}」的记录。"
            parts = []
            for h in hits:
                parts.append(f"=== {h['date']} ===")
                if h["summary"]:
                    parts.append(f"（那天：{h['summary']}）")
                parts.extend(h["snippets"])
            text = "\n".join(parts)
            return text[:max_chars]

        dates = store.list_dates()
        if not dates:
            return "目前还没有任何对话档案。"
        # 全量日期，但远期压缩成一段列举，避免几十行撑爆返回
        if len(dates) > 30:
            head = "、".join(dates[:-30])
            tail = "\n".join(dates[-30:])
            return (
                f"共 {len(dates)} 天档案。\n较早的日期：{head}\n最近的日期：\n{tail}"
            )
        return "可用的档案日期：" + "、".join(dates)

    # ------------------------------------------------------------ 上下文注入

    @filter.on_llm_request()
    async def inject_archive_index(self, event: AstrMessageEvent, req) -> None:
        """把"档案目录"塞进 system prompt，让模型知道哪天聊过什么。

        分层策略：近期带摘要，远期只留日期。
        这样档案攒到几百天时，注入量仍然可控（远期日期本身信息量就高于摘要）。
        """
        if not bool(self._cfg("inject_index", True)):
            return
        # 群聊里默认不注入档案目录：一份档案目录约 500 tokens，
        # 群聊是省 token 的主战场，这部分基本用不上。
        try:
            in_group = not event.is_private_chat()
        except Exception:
            in_group = False
        if in_group and not bool(self._cfg("inject_index_in_group", False)):
            return
        try:
            store = self.store()
            dates = store.list_dates()
            if not dates:
                return

            max_days = int(self._cfg("index_max_days", 60) or 60)
            detail_days = int(self._cfg("index_detail_days", 14) or 14)

            recent = dates[-max_days:]

            lines = [
                "",
                "【对话档案】你的长期记忆以按日期的文档形式保存，可以用 recall_archive 翻看任意一天。",
            ]

            # 远期：只列日期，省 token
            if len(recent) > detail_days:
                old = recent[:-detail_days]
                lines.append(
                    "早先的日子（需要细节就翻）：" + "、".join(old)
                )
                recent = recent[-detail_days:]

            # 近期：日期 + 摘要
            for d in recent:
                summ = store.summary_of(d)
                lines.append(f"- {d}" + (f"：{summ}" if summ else ""))

            if len(dates) > max_days:
                lines.append(
                    f"（总共有 {len(dates)} 天档案，更早的可以按关键词搜索）"
                )
            lines.append("用户提到过去的事情时，先翻档案再回答，不要凭空猜测。")

            req.system_prompt = (req.system_prompt or "") + "\n".join(lines)
        except Exception as e:
            logger.warning(f"[记忆归档] 注入档案目录失败: {e}")

    @filter.on_llm_request()
    async def inject_resume_context(self, event: AstrMessageEvent, req) -> None:
        """重置对话之后，把最近几轮接回去（v0.2）。

        判断方式：当前会话 history 是空的（刚 /reset），而今天有档案 ——
        说明上回聊完就被清空了。这时候塞进最后 N 轮原文，
        让她接着上文说，而不是重新打招呼。

        无状态设计：不依赖 reset 那一刻有没有收到钩子，
        重启、插件重载之后仍然有效。每个会话只塞一次，塞完标记，history 有内容就清标记。
        """
        count = int(self._cfg("resume_after_reset_turns", 6) or 0)
        if count <= 0:
            return
        try:
            if not event.is_private_chat():
                return
        except Exception:
            return

        umo = self._session_key(event)
        try:
            history = await self._current_history(event)
        except Exception:
            return
        if history:
            self._resumed.discard(umo)
            return
        if umo in self._resumed:
            return

        try:
            store = self.store()
            today = datetime.now().strftime("%Y-%m-%d")
            date = store.latest_date_with_archive(prefer=today)
            if not date:
                return
            turns = store.recent_turns(date, count)
            text = render_turns_compact(
                turns,
                bot_label=self._bot_name(),
                max_chars=int(self._cfg("resume_max_chars", 1200) or 1200),
            )
            if not text:
                return
            block = (
                "\n【刚重置过对话。下面是上回聊到的最后几轮，请你接着这个话头往下说，"
                "不要当成新话题，也不要重新自我介绍】\n"
                f"{text}\n"
            )
            req.system_prompt = (req.system_prompt or "") + block
            self._resumed.add(umo)
            logger.info(f"[记忆归档] 重置后续接：{date} 最近 {len(turns)} 轮")
        except Exception as e:
            logger.warning(f"[记忆归档] 续接失败: {e}")
