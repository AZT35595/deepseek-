"""把 AstrBot 对话历史归档成按日期命名的 Markdown 文档。

设计目标（与 AstrBot 解耦，方便单独测试）：
- 输入是 AstrBot 的 OpenAI 格式 history（list[dict]，role/content/...）
- 输出是 docs/<日期>.md，同一天多次存档会合并进同一个文件
- 每份文档带 YAML front-matter（日期、轮数、token 估算、摘要、下次提示）
- 支持按日期 / 关键词检索回去
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------- 文本清洗

# 这些内部标记不该进入归档文档，否则回忆时会把噪声一起灌回上下文
_NOISE_PATTERNS = [
    re.compile(r"<system_reminder>.*?</system_reminder>", re.S),
    re.compile(r"<system_reminder>.*", re.S),
    # 带尖括号的 DSML 标签：<||DSML||invoke> / <|DSML|...>
    re.compile(r"</?\|+\s*DSML\s*\|+[^>]*>", re.S),
    # 裸的 ||DSML|| 标记（DeepSeek 偶尔直接吐出来，没有尖括号）
    re.compile(r"\|+\s*DSML\s*\|+[A-Za-z_]*"),
    re.compile(r"\[函数调用\].*", re.S),
]


def clean_text(text: str) -> str:
    """去掉模型漏出的内部标签。"""
    if not text:
        return ""
    for pat in _NOISE_PATTERNS:
        text = pat.sub("", text)
    return text.strip()


def content_to_text(content: Any) -> str:
    """把 OpenAI 的 content（可能是 str 或 content parts 列表）压成纯文本。"""
    if content is None:
        return ""
    if isinstance(content, str):
        return clean_text(content)
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                itype = item.get("type", "")
                if itype == "text":
                    parts.append(str(item.get("text", "")))
                elif itype == "image_url":
                    parts.append("[图片]")
                elif itype == "audio_url":
                    parts.append("[语音]")
                # 其它类型（工具调用等）直接丢弃
        return clean_text("\n".join(p for p in parts if p))
    return clean_text(str(content))


def estimate_tokens(text: str) -> int:
    """粗略估算 token：中文按约 1.5 字/token，英文按约 4 字符/token。

    只用于给用户展示"这份档案大概多重"，不要求精确。
    """
    if not text:
        return 0
    cjk = len(re.findall(r"[\u4e00-\u9fff]", text))
    other = len(text) - cjk
    return int(cjk / 1.5 + other / 4)


# ---------------------------------------------------------------- 数据结构


@dataclass
class Turn:
    """一轮对话。"""

    user: str
    assistant: str
    ts: str = ""
    tool_note: str = ""
    """这一轮里工具调用的一行摘要。工具原始输出通常很大，只留概要。"""


@dataclass
class ArchiveResult:
    path: Path
    date: str
    turns_added: int
    turns_total: int
    tokens: int
    created: bool
    chars: int = 0
    summary: str = ""
    next_prompt: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": str(self.path),
            "date": self.date,
            "turns_added": self.turns_added,
            "turns_total": self.turns_total,
            "tokens": self.tokens,
            "created": self.created,
            "chars": self.chars,
            "summary": self.summary,
            "next_prompt": self.next_prompt,
        }


# ---------------------------------------------------------------- 解析 history


def summarize_tool_result(text: str, *, max_chars: int = 120) -> str:
    """把工具输出压成一行摘要。

    工具输出往往是几十行命令回显，原文既占 token 又没信息量，
    但"她调用了什么工具"这件事本身有价值，所以留个概要。
    """
    if not text:
        return ""

    # 尝试从 AstrBot 的 "Command completed with exit code N ... Output:" 取结论
    head = text[:400]
    exit_m = re.search(r"exit code (\d+)", head)
    cmd_m = re.search(r"wall time: ([\d.]+s)", head)

    bits: list[str] = []
    if exit_m:
        bits.append(f"exit {exit_m.group(1)}")
    if cmd_m:
        bits.append(cmd_m.group(1))

    # 取第一行有实质内容的东西
    meaningful = ""
    for line in text.splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith(("Command completed", "Output:", "----")):
            continue
        meaningful = s
        break

    parts = []
    if bits:
        parts.append("(" + ", ".join(bits) + ")")
    if meaningful:
        parts.append(meaningful[:max_chars])
    out = " ".join(parts).strip()
    return out[: max_chars + 30]


def history_to_turns(history: list[dict[str, Any]], *, with_tools: bool = True) -> list[Turn]:
    """把 AstrBot 的 OpenAI 格式 history 转成轮次列表。

    规则：一条 user 消息 + 其后第一条非空 assistant 消息 = 一轮。
    中间的 tool 消息不切断轮次；with_tools 为真时把工具调用压成一行摘要挂在轮上。
    """
    if not history:
        return []

    turns: list[Turn] = []
    pending_user: str | None = None
    pending_ts: str = ""
    pending_tools: list[str] = []

    def flush_tools() -> str:
        if not pending_tools:
            return ""
        if len(pending_tools) > 3:
            return "；".join(pending_tools[:3]) + f"（另有 {len(pending_tools) - 3} 项）"
        return "；".join(pending_tools)

    def attach_tools(note: str) -> None:
        """把工具摘要挂到最近一轮上。

        AstrBot 的 history 里 tool 消息有时出现在 assistant 之后，
        所以不能只在收 assistant 时结算，还要能回头补挂到上一轮。
        """
        if not note or not turns:
            return
        last = turns[-1]
        last.tool_note = (last.tool_note + "；" + note) if last.tool_note else note

    for msg in history:
        if not isinstance(msg, dict):
            continue
        role = msg.get("role")
        text = content_to_text(msg.get("content"))

        if role == "user":
            # 上一个 user 还没等到回复，先落一轮（assistant 留空）
            if pending_user is not None:
                turns.append(
                    Turn(user=pending_user, assistant="", ts=pending_ts, tool_note=flush_tools())
                )
            pending_user = text
            pending_ts = ""
            pending_tools = []
            continue

        if role == "assistant":
            if pending_user is None:
                continue
            # 空回复（纯工具调用）不结束这一轮，继续等真正的文本回复
            if not text:
                continue
            turns.append(
                Turn(user=pending_user, assistant=text, ts=pending_ts, tool_note=flush_tools())
            )
            pending_user = None
            pending_ts = ""
            pending_tools = []
            continue

        if role == "tool":
            if not with_tools:
                continue
            note = summarize_tool_result(text)
            if not note:
                continue
            # 这一轮还没结束 -> 先攒着；已经开始新的一轮 -> 补给上一轮
            if pending_user is not None:
                pending_tools.append(note)
            else:
                attach_tools(note)
            continue

        # system 等其它角色忽略

    if pending_user is not None:
        turns.append(
            Turn(user=pending_user, assistant="", ts=pending_ts, tool_note=flush_tools())
        )

    # 过滤掉完全空白的轮次
    return [t for t in turns if (t.user or t.assistant).strip()]


def turn_signature(turn: Turn) -> str:
    """生成用于去重的轮次指纹。"""
    raw = (turn.user or "")[:200] + "\u0000" + (turn.assistant or "")[:200]
    return str(hash(raw))


# ---------------------------------------------------------------- Markdown 读写

_FRONT_RE = re.compile(r"\A---\s*\n(.*?)\n---\s*\n", re.S)
_TURN_RE = re.compile(
    r"^### 轮\s*(\d+)\s*(?:·\s*(.+?))?\s*$\n(.*?)(?=^### 轮\s*\d+|^---\s*$\n^## |\Z)",
    re.S | re.M,
)
_USER_BLOCK = re.compile(r"^\*\*你\*\*\s*[:：]\s*(.*?)(?=^\*\*我\*\*|^\*\*小肥鲸鱼\*\*|\Z)", re.S | re.M)


def _parse_front_matter(text: str) -> tuple[dict[str, str], str]:
    m = _FRONT_RE.match(text)
    if not m:
        return {}, text
    meta: dict[str, str] = {}
    for line in m.group(1).splitlines():
        if ":" in line and not line.startswith(("  ", "-")):
            k, v = line.split(":", 1)
            meta[k.strip()] = v.strip().strip('"').strip("'")
    return meta, text[m.end() :]


def _render_doc(
    date: str,
    turns: list[Turn],
    summary: str,
    next_prompt: str,
    *,
    created_at: str,
    updated_at: str,
    bot_name: str,
    user_label: str,
) -> str:
    joined = "\n".join(t.user + t.assistant + t.tool_note for t in turns)
    tokens = estimate_tokens(joined)

    lines: list[str] = []
    lines.append("---")
    lines.append(f"date: {date}")
    lines.append(f"turns: {len(turns)}")
    lines.append(f"tokens: {tokens}")
    lines.append(f"created: {created_at}")
    lines.append(f"updated: {updated_at}")
    lines.append(f'summary: "{summary}"')
    lines.append(f'next: "{next_prompt}"')
    lines.append("---")
    lines.append("")
    lines.append(f"# {date} 对话档案")
    lines.append("")
    if summary:
        lines.append(f"> **这天聊了什么**：{summary}")
        lines.append("")
    if next_prompt:
        lines.append(f"> **下次接着聊**：{next_prompt}")
        lines.append("")
    lines.append(f"共 {len(turns)} 轮，约 {tokens} tokens。")
    lines.append("")

    for i, t in enumerate(turns, 1):
        ts = f" · {t.ts}" if t.ts else ""
        lines.append(f"### 轮 {i}{ts}")
        lines.append("")
        if t.tool_note:
            lines.append(f"*（用到工具：{t.tool_note}）*")
            lines.append("")
        if t.user:
            lines.append(f"**{user_label}**：{t.user}")
            lines.append("")
        if t.assistant:
            lines.append(f"**{bot_name}**：{t.assistant}")
            lines.append("")
        else:
            lines.append("*(这一轮没有留下回复)*")
            lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def _split_turns(body: str) -> list[Turn]:
    """从已有文档正文里读回轮次，用于合并去重。"""
    turns: list[Turn] = []
    # 按 ### 轮 分块
    blocks = re.split(r"^### 轮\s*\d+.*$", body, flags=re.M)
    if len(blocks) <= 1:
        return turns
    for blk in blocks[1:]:
        blk = blk.strip()
        if not blk:
            continue
        tool_note = ""
        tm = re.match(r"^\*（用到工具：(.+?)）\*\s*$", blk, re.M)
        if tm:
            tool_note = tm.group(1)
            blk = blk[tm.end() :].strip()
        user_m = re.search(r"^\*\*(.+?)\*\*\s*[:：]\s*", blk, re.M)
        if not user_m:
            turns.append(Turn(user="", assistant=clean_text(blk), tool_note=tool_note))
            continue
        # 按 **名字**： 切分说话人块
        parts = re.split(r"^\*\*(.+?)\*\*\s*[:：]\s*", blk, flags=re.M)
        # parts = ['', name1, text1, name2, text2, ...]
        pairs = list(zip(parts[1::2], parts[2::2]))
        user_text = ""
        assistant_text = ""
        for name, text in pairs:
            text = clean_text(text)
            if not user_text:
                user_text = text
            else:
                assistant_text = (assistant_text + "\n" + text).strip() if assistant_text else text
        turns.append(Turn(user=user_text, assistant=assistant_text, tool_note=tool_note))
    return turns


def render_turns_compact(
    turns: list[Turn],
    *,
    user_label: str = "你",
    bot_label: str = "她",
    max_chars: int = 1200,
) -> str:
    """把若干轮压成一段紧凑文本，用于「重置之后接着聊」。

    从最近的往回取，超过 max_chars 就丢掉更早的轮次——
    宁可少带两轮，也不要把一段超长原文塞进每次请求。
    """
    picked: list[str] = []
    used = 0
    for turn in reversed(turns or []):
        user = clean_text(turn.user or "")
        reply = clean_text(turn.assistant or "")
        block = f"{user_label}：{user}\n{bot_label}：{reply}".strip()
        if not block:
            continue
        if picked and used + len(block) > max_chars:
            break
        picked.append(block)
        used += len(block)
    if not picked:
        return ""
    picked.reverse()
    return "\n\n".join(picked)[:max_chars]


class ArchiveStore:
    """管理 docs 目录下的按日期档案。"""
    def __init__(self, docs_dir: Path | str, *, bot_name: str = "小肥鲸鱼") -> None:
        self.docs_dir = Path(docs_dir)
        self.bot_name = bot_name

    # ---------------------------------------------------------- 路径
    def path_for(self, date: str) -> Path:
        return self.docs_dir / f"{date}.md"

    def list_dates(self) -> list[str]:
        if not self.docs_dir.is_dir():
            return []
        out = []
        for p in self.docs_dir.glob("*.md"):
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", p.stem):
                out.append(p.stem)
        return sorted(out)

    # ---------------------------------------------------------- 读
    def read(self, date: str) -> tuple[dict[str, str], str] | None:
        p = self.path_for(date)
        if not p.is_file():
            return None
        text = p.read_text(encoding="utf-8", errors="replace")
        return _parse_front_matter(text)

    def read_body(self, date: str) -> str:
        p = self.path_for(date)
        if not p.is_file():
            return ""
        text = p.read_text(encoding="utf-8", errors="replace")
        _, body = _parse_front_matter(text)
        return body

    def recent_turns(self, date: str, count: int) -> list[Turn]:
        """取某天档案里最后 count 轮。

        用于"重置对话之后接着聊"：把最近几轮原文还给她，
        不需要重新灌一整天，token 可控。
        """
        if count <= 0:
            return []
        body = self.read_body(date)
        if not body:
            return []
        turns = _split_turns(body)
        return turns[-count:] if len(turns) > count else turns

    def latest_date_with_archive(self, *, prefer: str = "") -> str:
        """优先返回 prefer（通常是今天），否则返回最近一个有档案的日期。"""
        if prefer and self.path_for(prefer).is_file():
            return prefer
        dates = self.list_dates()
        return dates[-1] if dates else ""

    def summary_of(self, date: str) -> str:
        got = self.read(date)
        if not got:
            return ""
        meta, _ = got
        return meta.get("summary", "")

    def tokens_of(self, date: str) -> int:
        got = self.read(date)
        if not got:
            return 0
        try:
            return int(got[0].get("tokens", "0"))
        except ValueError:
            return 0

    # ---------------------------------------------------------- 写
    def append_turns(
        self,
        date: str,
        new_turns: list[Turn],
        *,
        summary: str = "",
        next_prompt: str = "",
        overlap: int = 0,
    ) -> ArchiveResult:
        """把新轮次合并进 date 对应的档案。

        overlap: 允许与文末重复的轮数（用于处理 history 窗口重叠）。
        同一轮内容如果已经在档案末尾出现过，就不重复写入。
        """
        self.docs_dir.mkdir(parents=True, exist_ok=True)
        path = self.path_for(date)
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        existing_turns: list[Turn] = []
        created_at = now
        old_summary = ""
        old_next = ""
        if path.is_file():
            text = path.read_text(encoding="utf-8", errors="replace")
            meta, body = _parse_front_matter(text)
            existing_turns = _split_turns(body)
            created_at = meta.get("created", now) or now
            old_summary = meta.get("summary", "")
            old_next = meta.get("next", "")

        # ---- 去重：只保留真正新增的部分
        # 用「文末已有的轮次」与新轮次的开头做对齐，找到重叠边界
        added: list[Turn] = []
        if existing_turns:
            tail = existing_turns[-max(1, overlap) :] if overlap > 0 else existing_turns[-1:]
            tail_keys = [(t.user or "")[:80] + "|" + (t.assistant or "")[:80] for t in tail]
            start_idx = 0
            for i, t in enumerate(new_turns):
                key = (t.user or "")[:80] + "|" + (t.assistant or "")[:80]
                if key in tail_keys:
                    start_idx = i + 1
            added = new_turns[start_idx:]
        else:
            added = list(new_turns)

        # 末尾完全相同的轮次再挡一次
        if added and existing_turns:
            last_key = (existing_turns[-1].user or "")[:80] + "|" + (existing_turns[-1].assistant or "")[:80]
            first_key = (added[0].user or "")[:80] + "|" + (added[0].assistant or "")[:80]
            if last_key == first_key:
                added = added[1:]

        all_turns = existing_turns + added
        final_summary = summary or old_summary
        final_next = next_prompt or old_next

        doc = _render_doc(
            date,
            all_turns,
            final_summary,
            final_next,
            created_at=created_at,
            updated_at=now,
            bot_name=self.bot_name,
            user_label="你",
        )
        path.write_text(doc, encoding="utf-8")

        joined = "\n".join(t.user + t.assistant + t.tool_note for t in all_turns)
        return ArchiveResult(
            path=path,
            date=date,
            turns_added=len(added),
            turns_total=len(all_turns),
            tokens=estimate_tokens(joined),
            created=not existing_turns,
            chars=len(joined),
            summary=final_summary,
            next_prompt=final_next,
        )

    # ---------------------------------------------------------- 检索
    def search(self, keyword: str, *, limit: int = 5, context_lines: int = 3) -> list[dict[str, Any]]:
        """在全部档案里搜关键词，返回命中的日期与片段。

        先找关键词所在行，再把它前后几行取出来，方便还原上下文。
        """
        kw = keyword.strip()
        if not kw:
            return []
        hits: list[dict[str, Any]] = []
        for date in reversed(self.list_dates()):  # 最近的优先
            body = self.read_body(date)
            if not body:
                continue
            lines = body.splitlines()
            found: list[str] = []
            for i, line in enumerate(lines):
                if kw.lower() in line.lower():
                    lo = max(0, i - context_lines)
                    hi = min(len(lines), i + context_lines + 1)
                    snippet = "\n".join(lines[lo:hi]).strip()
                    if snippet and snippet not in found:
                        found.append(snippet)
                    if len(found) >= 3:
                        break
            if found:
                hits.append(
                    {
                        "date": date,
                        "summary": self.summary_of(date),
                        "snippets": found,
                    }
                )
                if len(hits) >= limit:
                    break
        return hits


# ---------------------------------------------------------------- 日期解析

_CN_DATE = re.compile(r"(\d{4})\s*[年\-/\.]\s*(\d{1,2})\s*[月\-/\.]\s*(\d{1,2})")
_RELATIVE = {
    "今天": 0,
    "今日": 0,
    "昨天": 1,
    "昨日": 1,
    "前天": 2,
    "大前天": 3,
}


def normalize_date(text: str, *, today: datetime | None = None) -> str | None:
    """从自然语言里解析出 YYYY-MM-DD。

    支持：2026-10-28 / 2026年10月28日 / 10月28日 / 今天 / 昨天 / 前天 / N天前
    """
    if not text:
        return None
    today = today or datetime.now()
    s = text.strip()

    m = _CN_DATE.search(s)
    if m:
        try:
            raw = f"{int(m.group(1)):04d}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
            return datetime.strptime(raw, "%Y-%m-%d").strftime("%Y-%m-%d")
        except ValueError:
            return None

    # 只有月日，例如 "10月28号"
    m2 = re.search(r"(\d{1,2})\s*[月\-/]\s*(\d{1,2})\s*[日号]?", s)
    if m2:
        try:
            return datetime(
                today.year, int(m2.group(1)), int(m2.group(2))
            ).strftime("%Y-%m-%d")
        except ValueError:
            return None

    for word, delta in _RELATIVE.items():
        if word in s:
            from datetime import timedelta

            return (today - timedelta(days=delta)).strftime("%Y-%m-%d")

    m3 = re.search(r"(\d+)\s*天前", s)
    if m3:
        from datetime import timedelta

        return (today - timedelta(days=int(m3.group(1)))).strftime("%Y-%m-%d")

    return None


def dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2, default=str)
